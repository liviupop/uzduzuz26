"""Break one gate at a time (stuck at 0 or 1). Does the ritual notice?
conformance only, and the full ceremony (boot, mirror, adder, conformance)."""
import random, sys, isa
from multiprocessing import Pool
from nand import build_cpu, Sim

STEPS = [("boot", 0, 0, 15000), ("mirror", 0x55, 0, 60), ("mirror", 0xAA, 0, 60),
         ("adder", 0x9C, 0, 600), ("adder", 0x63, 0, 600), ("conformance", 1, 0, 2000)]

def run(fault, steps):
    out = []
    c, p = build_cpu()
    if fault:
        gi, st = fault
        a, b, o = c.gates[gi]
        k = c.const1 if st == 0 else c.const0
        c.gates[gi] = (k, k, o)
    for prog, sw, cyc, maxc in steps:
        s = Sim(c, p)
        s.mem = list(isa.load(prog)); s.mem[isa.CYCLE] = cyc; s.switches = sw
        try:
            s.reset(); s.run(maxc)
            out.append((tuple(s.tape[:20]), s.get("H")))
        except RuntimeError:
            out.append("oscillates")
    return out

def job(args):
    fault, which = args
    steps = STEPS[-1:] if which == "conf" else STEPS
    return which, run(fault, steps) != HEALTHY[which]

HEALTHY = {"conf": run(None, STEPS[-1:]), "all": run(None, STEPS)}

if __name__ == "__main__":
    c, _ = build_cpu()
    random.seed(1)
    sample = random.sample(range(len(c.gates)), 200)
    faults = [(g, st) for g in sample for st in (0, 1)]
    with Pool() as pool:
        res = pool.map(job, [(f, w) for w in ("conf", "all") for f in faults], chunksize=8)
    for w, label in (("conf", "conformance alone"), ("all", "full ceremony")):
        hits = [caught for ww, caught in res if ww == w]
        print("%s catches %d of %d single broken gates (%.1f%%)" % (label, sum(hits), len(hits), 100 * sum(hits) / len(hits)))
