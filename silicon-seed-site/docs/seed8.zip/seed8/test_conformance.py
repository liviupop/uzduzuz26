"""Run every program on the reference and on the NAND machine; they must agree."""
import time, random, isa
from nand import build_cpu, Sim

def gate_run(prog, switches=0, cyc=0, max_cycles=300000):
    c, p = build_cpu()
    s = Sim(c, p)
    s.mem = list(isa.load(prog))
    s.mem[isa.CYCLE] = cyc
    s.switches = switches
    s.reset()
    s.run(max_cycles)
    return s

if __name__ == "__main__":
    c, _ = build_cpu()
    print("CPU: %d NAND gates" % len(c.gates))
    ok, t = True, time.time()
    s = gate_run("boot"); ref = isa.Machine(isa.load("boot")).run()
    print("boot   gates:", s.tape, "crank turns", s.cycles)
    ok &= s.tape == ref.tape and s.mem == ref.m
    years = [1, 2, 3, 7, 100, 255, 256, 300, 974, 1000]
    random.seed(5); years += random.sample(range(1, 1001), 40)
    bad = 0
    for y in years:
        s = gate_run("conformance", switches=y & 255, cyc=y >> 8)
        got, want = (s.tape[-2] << 8) | s.tape[-1], isa.number_of_the_year(y)
        bad += got != want
        if y in years[:10]:
            print("year %4d (%d): gates 0x%04X  reference 0x%04X" % (y, 2026 + y, got, want))
    print("years checked:", len(years), "mismatches:", bad); ok &= bad == 0
    for prog, sw in [("adder", 0x35), ("adder", 0xF9), ("adder", 0xFF), ("mirror", 0xA5)]:
        s = gate_run(prog, switches=sw, max_cycles=1500)
        ref = isa.Machine(isa.load(prog), switches=sw); [ref.step() for _ in range(500)]
        same = s.tape[:1] == ref.tape[:1]; ok &= same
        print(prog, hex(sw), "gates", s.tape[:2], "reference", ref.tape[:2])
    print("time %.1fs" % (time.time() - t))
    print("ALL MATCH" if ok else "FAILURES")
