"""Seed-8 v0.2 built from two-input NAND gates only.

The two seeds:
  - the NAND gate computes: its lamp is off only when both of its inputs are on;
  - the feedback loop remembers: two NAND gates feeding each other hold one bit.

Each bit of the machine's memory inside the processor is a "pair of hands":
the first hand (latch) takes the new value while the crank is on phase 1, the
second hand passes it on during phase 2. The two phases never overlap, so a
value can never run through the whole machine in one go.

The 256 boxes of memory are not made of gates. They are a separate woven block,
like core rope and magnetic core memory. Box 254 is the switches, box 255 the lamps.
"""

import json


class Circuit:
    def __init__(self):
        self.n = 0
        self.gates = []                 # (input a, input b, output)
        self.const0 = self.wire()
        self.const1 = self.wire()
        self.inputs = {}
        self.alias = {}                 # placeholder wire -> real wire
        self.marks = []                 # (part name, gate count when it starts)

    def mark(self, name):
        self.marks.append((name, len(self.gates)))

    def wire(self):
        self.n += 1
        return self.n - 1

    def nand_into(self, a, b, out):
        self.gates.append((a, b, out))
        return out

    def nand(self, a, b):
        return self.nand_into(a, b, self.wire())

    def input(self, name, width=1):
        ws = [self.wire() for _ in range(width)]
        self.inputs[name] = ws
        return ws if width > 1 else ws[0]

    # everything else is NAND gates
    def NOT(self, a):        return self.nand(a, a)                          # 1 gate
    def AND(self, a, b):     return self.NOT(self.nand(a, b))                # 2 gates
    def OR(self, a, b):      return self.nand(self.NOT(a), self.NOT(b))      # 3 gates

    def XOR(self, a, b):                                                     # 4 gates
        t = self.nand(a, b)
        return self.nand(self.nand(a, t), self.nand(b, t))

    def MUX(self, s, ns, a0, a1):    # s ? a1 : a0, with NOT s given (3 gates)
        return self.nand(self.nand(a1, s), self.nand(a0, ns))

    def ANDN(self, xs):
        r = xs[0]
        for x in xs[1:]:
            r = self.AND(r, x)
        return r

    def ORN(self, xs):
        r = xs[0]
        for x in xs[1:]:
            r = self.OR(r, x)
        return r

    # one bit of memory: the feedback loop
    def latch(self, d, enable, q):
        """Gated D latch, four NAND gates. Enable on: it follows d. Off: it remembers."""
        s_ = self.nand(d, enable)
        r_ = self.nand(s_, enable)
        qb = self.wire()
        self.nand_into(s_, qb, q)
        self.nand_into(r_, q, qb)
        return q

    def register(self, width, phi2, take):
        """width bits; each bit is two latches (8 gates). 'take' is phase 1 AND load."""
        ds = [self.wire() for _ in range(width)]          # placeholders, wired later
        qs = []
        for d in ds:
            m, q = self.wire(), self.wire()
            self.latch(d, take, m)
            self.latch(m, phi2, q)
            qs.append(q)
        return ds, qs

    def connect(self, placeholders, real):
        for p, r in zip(placeholders, real):
            self.alias[p] = r

    def finish(self):
        """Replace every placeholder by the wire it was connected to (costs no gates)."""
        def res(w):
            while w in self.alias:
                w = self.alias[w]
            return w
        self.gates = [(res(a), res(b), o) for a, b, o in self.gates]

    # arithmetic
    def full_adder(self, a, b, c):                       # 9 gates
        t1 = self.nand(a, b)
        t2 = self.nand(a, t1)
        t3 = self.nand(b, t1)
        s1 = self.nand(t2, t3)                           # a XOR b
        t4 = self.nand(s1, c)
        t5 = self.nand(s1, t4)
        t6 = self.nand(c, t4)
        s = self.nand(t5, t6)                            # sum
        cout = self.nand(t1, t4)                         # carry
        return s, cout

    def half_adder(self, a, b):                          # 5 gates
        t1 = self.nand(a, b)
        s = self.nand(self.nand(a, t1), self.nand(b, t1))
        return s, self.NOT(t1)


def build_cpu():
    c = Circuit()
    phi1, phi2, reset = c.input("phi1"), c.input("phi2"), c.input("reset")
    mem_in = c.input("mem_in", 8)            # the number coming back from the boxes
    c.mark("telling each part when to load, and reset")
    nreset = c.NOT(reset)
    # registers: (name, width, needs reset)
    loads = {}

    def reg(name, width):
        en = c.wire()                                     # placeholder: "load now"
        take = c.AND(phi1, en)
        ds, qs = c.register(width, phi2, take)
        loads[name] = (ds, en)
        return qs

    c.mark("remembered bits: hand, bookmark, job, box, carry, stop, step (31 bits)")
    A = reg("A", 8)          # the hand
    PC = reg("PC", 8)        # the pawn
    JOB = reg("JOB", 3)      # which job
    BOX = reg("BOX", 8)      # which box the job is about
    C = reg("C", 1)[0]       # carry lamp
    H = reg("H", 1)[0]       # stop lamp
    S = reg("S", 2)          # which step of the job: read job, read box, do it
    s0, s1 = S

    c.mark("step counter: read job, read box, do it")
    # where in the job are we?
    ns0, ns1 = c.NOT(s0), c.NOT(s1)
    step1 = c.AND(ns1, ns0)              # read the job
    step2 = c.AND(ns1, s0)               # read the box number
    step3 = s1                           # do it
    nstep3 = ns1
    go = c.NOT(H)

    c.mark("job decoder: which of the 8 jobs")
    # which job? 3 bits -> 8 lines
    j0, j1, j2 = JOB
    nj0, nj1, nj2 = c.NOT(j0), c.NOT(j1), c.NOT(j2)
    low = [c.AND(nj1, nj0), c.AND(nj1, j0), c.AND(j1, nj0), c.AND(j1, j0)]
    job = [c.AND(low[k & 3], nj2 if k < 4 else j2) for k in range(8)]
    STOP, LOAD, STORE, ADD, NANDJ, JUMP, JZ, JC = job

    c.mark("adder: 8 columns of school addition")
    # the hand: LOAD takes the box, ADD adds it, NAND does the gate on all 8 bits
    sums, carry = [], None
    for i in range(8):
        if i == 0:
            s, carry = c.half_adder(A[0], mem_in[0])
        else:
            s, carry = c.full_adder(A[i], mem_in[i], carry)
        sums.append(s)
    c.mark("choosing what goes in the hand: LOAD, ADD or NAND")
    new_hand = []
    for i in range(8):
        n1 = c.nand(LOAD, mem_in[i])
        n2 = c.nand(ADD, sums[i])
        n3 = c.nand(NANDJ, c.nand(A[i], mem_in[i]))
        new_hand.append(c.nand(c.AND(n1, n2), n3))
    writes_hand = c.ORN([LOAD, ADD, NANDJ])

    c.mark("EMPTY lamp: is the hand 0?")
    # EMPTY lamp: the hand holds 0 (not stored, just looked at)
    empty = c.ANDN([c.NOT(a) for a in A])

    c.mark("bookmark: move on by one, or jump")
    # the pawn: +1 after each read, or jump
    doing = c.AND(go, step3)
    jumps = c.AND(step3, c.ORN([JUMP, c.AND(JZ, empty), c.AND(JC, C)]))
    njumps = c.NOT(jumps)
    plus1 = []
    cy = PC[0]
    plus1.append(c.NOT(PC[0]))
    for i in range(1, 8):
        plus1.append(c.XOR(PC[i], cy))
        if i < 7:
            cy = c.AND(PC[i], cy)
    pc_next = [c.MUX(jumps, njumps, plus1[i], BOX[i]) for i in range(8)]

    c.mark("telling each part when to load, and reset ")
    def wire_reg(name, values, load, with_reset):
        ds, en = loads[name]
        if with_reset:
            values = [c.AND(v, nreset) for v in values]
            load = c.OR(load, reset)
        c.connect(ds, values)
        c.connect([en], [load])

    wire_reg("S", [step1, step2], go, True)
    wire_reg("PC", pc_next, c.AND(go, c.ORN([step1, step2, jumps])), True)
    wire_reg("JOB", mem_in[:3], c.AND(go, step1), False)
    wire_reg("BOX", mem_in, c.AND(go, step2), False)
    wire_reg("A", new_hand, c.AND(doing, writes_hand), False)
    wire_reg("C", [carry], c.AND(doing, ADD), True)
    wire_reg("H", [c.const1], c.AND(doing, STOP), True)

    c.mark("which box to look at")
    # which box to look at: the pawn's box while reading, the job's box while doing
    addr = [c.MUX(step3, nstep3, PC[i], BOX[i]) for i in range(8)]
    write = c.AND(doing, STORE)
    c.mark("end")
    c.finish()

    ports = {
        "phi1": [phi1], "phi2": [phi2], "reset": [reset], "mem_in": mem_in,
        "addr": addr, "write": [write], "A": A, "PC": PC, "JOB": JOB, "BOX": BOX,
        "S": S, "C": [C], "H": [H], "EMPTY": [empty],
    }
    return c, ports


class Sim:
    """Only gates whose inputs changed are looked at again, until nothing changes."""

    SWITCHES, LAMPS = 254, 255

    def __init__(self, circuit, ports):
        self.c, self.p = circuit, ports
        self.v = [0] * circuit.n
        self.v[circuit.const1] = 1
        self.fan = [[] for _ in range(circuit.n)]
        for gi, (a, b, o) in enumerate(circuit.gates):
            self.fan[a].append(gi)
            if b != a:
                self.fan[b].append(gi)
        self.mem = [0] * 256
        self.switches = 0
        self.tape = []
        self.cycles = 0
        self.queue = list(range(len(circuit.gates)))
        self.settle()

    def set(self, port, value):
        for i, w in enumerate(self.p[port]):
            bit = (value >> i) & 1
            if self.v[w] != bit:
                self.v[w] = bit
                self.queue.extend(self.fan[w])

    def get(self, port):
        r = 0
        for i, w in enumerate(self.p[port]):
            r |= self.v[w] << i
        return r

    def read_box(self, box):
        return self.switches & 255 if box == self.SWITCHES else self.mem[box]

    def settle(self):
        g, v, fan = self.c.gates, self.v, self.fan
        for _ in range(100):
            q, self.queue = self.queue, []
            budget = 50 * len(g)
            while q:
                a, b, o = g[q.pop()]
                budget -= 1
                if budget < 0:
                    raise RuntimeError("circuit oscillates")
                nv = 0 if (v[a] and v[b]) else 1
                if v[o] != nv:
                    v[o] = nv
                    q.extend(fan[o])
            self.set("mem_in", self.read_box(self.get("addr")))
            if not self.queue:
                return
        raise RuntimeError("circuit did not settle")

    def clock(self):
        self.set("phi1", 1); self.settle()
        write, box, hand = self.get("write"), self.get("addr"), self.get("A")
        self.set("phi1", 0); self.settle()
        if write:                         # between the phases the woven memory takes its write
            self.mem[box] = hand
            if box == self.LAMPS:
                self.tape.append(hand)
            self.set("mem_in", self.read_box(self.get("addr"))); self.settle()
        self.set("phi2", 1); self.settle()
        self.set("phi2", 0); self.settle()
        self.cycles += 1

    def reset(self):
        self.set("reset", 1)
        self.clock(); self.clock()
        self.set("reset", 0); self.settle()
        self.tape, self.cycles = [], 0

    def run(self, max_cycles=200000):
        while not self.get("H") and self.cycles < max_cycles:
            self.clock()
        return self


def gate_budget():
    """How many gates each part of the machine uses."""
    c, _ = build_cpu()
    totals = {}
    for (name, at), (_, nxt) in zip(c.marks, c.marks[1:]):
        name = name.strip()
        totals[name] = totals.get(name, 0) + nxt - at
    return list(totals.items())


if __name__ == "__main__":
    c, ports = build_cpu()
    print("NAND gates:", len(c.gates))
    for name, n in gate_budget():
        print("%5d  %s" % (n, name))
