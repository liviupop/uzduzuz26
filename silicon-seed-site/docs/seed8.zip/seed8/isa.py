"""Seed-8, version 0.2: eight jobs.

Plain picture of the machine:
  - a row of 256 numbered boxes (memory); each box holds one number from 0 to 255
  - a hand (A) that holds one number
  - a pawn (PC) that stands on the box to read next, like a pawn on a board
  - two little lamps: CARRY (the last addition went past 255) and EMPTY (the hand holds 0)

Every job takes two boxes: the first says WHICH job (0 to 7), the second says
WHICH BOX the job is about.

Box 254 is wired to the eight switches: reading it gives what the switches show.
Box 255 is wired to the eight lamps: writing to it lights them.
Box 253 holds the year's high part when the year index is above 255.
"""

JOBS = {
    "STOP":  0,  # stop the machine
    "LOAD":  1,  # hand = box
    "STORE": 2,  # box = hand
    "ADD":   3,  # hand = hand + box; CARRY lights if it went past 255
    "NAND":  4,  # hand = NOT(hand AND box), bit by bit: the gate the machine is made of
    "JUMP":  5,  # next job is at box
    "JZ":    6,  # if the hand is empty (0), next job is at box
    "JC":    7,  # if CARRY is lit, next job is at box
}
NAMES = {v: k for k, v in JOBS.items()}
SWITCHES, LAMPS, CYCLE = 254, 255, 253


def assemble(src):
    """Two-pass assembler. Returns a 256-box memory and the label table."""
    lines = []
    for raw in src.splitlines():
        line = raw.split(";")[0].strip()
        if line:
            lines.append(line)
    base = {"switches": SWITCHES, "lamps": LAMPS, "cycle": CYCLE}

    def one_pass(final):
        labels = dict(base)
        if final:
            labels.update(final)
        mem, addr, seen = [0] * 256, 0, {}
        for line in lines:
            while ":" in line:
                lab, line = line.split(":", 1)
                seen[lab.strip()] = addr
                line = line.strip()
            if not line:
                continue
            parts = line.split()
            word, arg = parts[0].upper(), (parts[1] if len(parts) > 1 else None)
            if word == ".BYTE":
                mem[addr] = val(arg, labels, final) & 255
                addr += 1
                continue
            if word not in JOBS:
                raise ValueError("unknown job: " + line)
            mem[addr] = JOBS[word]
            mem[addr + 1] = 0 if word == "STOP" else val(arg, labels, final) & 255
            addr += 2
        if addr > CYCLE:
            raise ValueError("program runs into the special boxes")
        return mem, seen

    _, labels = one_pass(None)
    mem, labels2 = one_pass(labels)
    return mem, labels2


def val(tok, labels, final):
    if tok is None:
        raise ValueError("missing box number")
    if tok.lower().startswith("0x"):
        return int(tok, 16)
    if tok.isdigit():
        return int(tok)
    if tok in labels:
        return labels[tok]
    if final is None:
        return 0
    raise ValueError("unknown label: " + tok)


class Machine:
    """Reference: the machine described one job at a time."""

    def __init__(self, mem, switches=0):
        self.m = list(mem)
        self.a = self.pc = self.c = 0
        self.halted = False
        self.switches = switches
        self.tape = []
        self.steps = 0

    def read(self, box):
        return self.switches & 255 if box == SWITCHES else self.m[box]

    def step(self):
        if self.halted:
            return
        job, box = self.m[self.pc] & 7, self.m[(self.pc + 1) & 255]
        self.pc = (self.pc + 2) & 255
        name = NAMES[job]
        if name == "STOP":
            self.halted = True
        elif name == "LOAD":
            self.a = self.read(box)
        elif name == "STORE":
            self.m[box] = self.a
            if box == LAMPS:
                self.tape.append(self.a)
        elif name == "ADD":
            s = self.a + self.read(box)
            self.a, self.c = s & 255, s >> 8
        elif name == "NAND":
            self.a = (~(self.a & self.read(box))) & 255
        elif name == "JUMP":
            self.pc = box
        elif name == "JZ":
            if self.a == 0:
                self.pc = box
        elif name == "JC":
            if self.c:
                self.pc = box
        self.steps += 1

    def run(self, max_steps=200000):
        while not self.halted and self.steps < max_steps:
            self.step()
        return self


def load(name):
    import os
    here = os.path.dirname(os.path.abspath(__file__))
    with open(os.path.join(here, "programs", name + ".s")) as f:
        return assemble(f.read())[0]


def number_of_the_year(year_index):
    """Year 1 = 2027. Low part on the switches, high part in box 253."""
    mem = load("conformance")
    mem[CYCLE] = (year_index >> 8) & 255
    m = Machine(mem, switches=year_index & 255).run()
    return (m.tape[-2] << 8) | m.tape[-1]
