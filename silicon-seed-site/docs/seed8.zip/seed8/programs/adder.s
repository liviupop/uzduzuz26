; ADDER: the right four switches are one number (0-15), the left four another.
; The lamps show their sum.
start:  LOAD switches
        NAND k15         ; keep only the right four bits: (sw NAND 15), then NOT
        STORE t
        NAND t
        STORE sum        ; sum = right number
        NAND sum         ; rest = switches - right number = left number x 16
        ADD one
        ADD switches
        STORE rest
count:  LOAD rest        ; count the sixteens in rest, adding one to sum each time
        JZ show
        ADD minus16
        STORE rest
        LOAD sum
        ADD one
        STORE sum
        JUMP count
show:   LOAD sum
        STORE lamps
        JUMP start
k15:    .byte 15
one:    .byte 1
minus16: .byte 240
t:      .byte 0
sum:    .byte 0
rest:   .byte 0
