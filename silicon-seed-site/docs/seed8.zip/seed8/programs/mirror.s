; MIRROR: the lamps copy the switches, forever.
loop:   LOAD switches
        STORE lamps
        JUMP loop
