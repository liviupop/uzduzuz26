; BOOT: the first sign of life.
; The lamps count 1, 2, 3. Then the machine looks for the prime numbers up to 31
; on its own and shows each one: 2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31.
; A number is prime if no smaller number from 2 up fits into it exactly.
; To test "does d fit into n", the machine takes d away from n again and again.
        LOAD one
        STORE lamps
        LOAD two
        STORE lamps
        LOAD three
        STORE lamps
        LOAD two
        STORE n          ; start with n = 2
nloop:  LOAD two
        STORE d          ; try dividing by d = 2 first
dloop:  LOAD d           ; make "minus d": flip every bit of d, add one
        NAND d
        ADD one
        STORE negd
        ADD n            ; n - d
        JZ isprime       ; d has reached n: nothing fitted, n is prime
        LOAD n           ; r = n
modl:   ADD negd         ; r = r - d
        JZ notprime      ; nothing left over: d fits exactly
        JC modl          ; something left, more than d: take d away again
        LOAD d           ; went below zero: d does not fit, try d + 1
        ADD one
        STORE d
        JUMP dloop
isprime: LOAD n
        STORE lamps      ; show the prime
notprime: LOAD n
        ADD one
        STORE n
        ADD minus32      ; n + 1 = 32 ?
        JZ end
        JUMP nloop
end:    STOP
one:    .byte 1
two:    .byte 2
three:  .byte 3
minus32: .byte 224       ; 224 + 32 = 256, which wraps round to 0
n:      .byte 0
d:      .byte 0
negd:   .byte 0
