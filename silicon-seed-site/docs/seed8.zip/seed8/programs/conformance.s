; CONFORMANCE: the number of the year.
; Put the year index on the switches (year 1 = 2027). For years above 255,
; the high part goes in box 253.
; The machine stirs the year through 24 rounds that use all eight jobs, then
; shows two numbers on the lamps: the high part, then the low part.
; Every round can be undone, so two different years never give the same number.
; Every honest Seed-8, in wood, relays, transistors or chips, must show the same two.
        LOAD cycle
        ADD k90          ; h = high part + 90
        STORE h
        LOAD switches
        ADD k165         ; l = low part + 165
        STORE l
        LOAD k24
        STORE i          ; 24 rounds
round:  LOAD l           ; f = l turned one step left (double it; what falls off comes back)
        ADD l
        JC wrap
        JUMP nowrap
wrap:   ADD one
nowrap: NAND k147        ; f = NOT(f AND 147)
        ADD i
        ADD h
        STORE h          ; h = h + f(l, i)
        LOAD h
        NAND h           ; g = NOT h
        ADD k55
        ADD l
        STORE l          ; l = l + g(h)
        LOAD i
        ADD minus1
        STORE i
        JZ done
        JUMP round
done:   LOAD h
        STORE lamps
        LOAD l
        STORE lamps
        STOP
one:    .byte 1
minus1: .byte 255
k24:    .byte 24
k55:    .byte 55
k90:    .byte 90
k147:   .byte 147
k165:   .byte 165
h:      .byte 0
l:      .byte 0
i:      .byte 0
